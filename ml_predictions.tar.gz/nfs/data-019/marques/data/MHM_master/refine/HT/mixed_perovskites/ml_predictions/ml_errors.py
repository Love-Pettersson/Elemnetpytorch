#!/usr/bin/env python

import sys, re

fin = open("energy", "r")
dft_energy = {}
for line in fin:
  fields = line.split()
  comp = fields[0].split("/")[0]
  els = re.sub( r"([A-Z])", r" \1", comp).split()
  if len(set(els)) != len(els): # I have some repeated elements by mistake
    continue
  if fields[0][-1] == "b":
    comp = els[1] + els[0] + els[2] + els[3]
  dft_energy[comp] = float(fields[3])
fin.close()

fin = open("ml_predictions_1.dat", "r")
ml1_energy = {}
for line in fin:
  fields = line.split()
  comp = fields[1]
  ml1_energy[comp] = float(fields[2])*1000.0
fin.close()

fin = open("ml_predictions_2.dat", "r")
ml2_energy = {}
for line in fin:
  fields = line.split()
  comp = fields[1]
  ml2_energy[comp] = float(fields[2])
fin.close()

mae1 = 0.0
mae2 = 0.0
for comp in dft_energy:
  mae1 += abs(dft_energy[comp] - ml1_energy[comp])
  mae2 += abs(dft_energy[comp] - ml2_energy[comp])
  #print comp, dft_energy[comp], ml1_energy[comp], ml2_energy[comp]
  
mae1 /= len(dft_energy)
mae2 /= len(dft_energy)

print mae1, mae2
